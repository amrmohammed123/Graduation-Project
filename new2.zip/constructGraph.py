import os
#for multiple apk folders use constructAllGraphs
#for one apk folder user constructGraph
import time
import mapping_Final
import extractHardwareFeatures
import changeFormat
import permissionsSmali
import methodType
def constructAllGraphs(path, permissionRef):
    for filename in os.listdir(path):
        methodsDictionary = {'dummyMain':0}
        methodsArray = []
        global adjacencyIndex
        adjacencyIndex = 1
        constructGraph(os.path.join(path,filename), methodsDictionary, True, methodsArray, permissionRef)
        #get permissions
        permissionsDict = mapping_Final.extractPermissions(methodsDictionary, os.path.join(path,filename,
                                                                    'AndroidManifest.xml'), permissionRef)
        # get hardware features
        hardwareDictionary = extractHardwareFeatures.extractHardwareFeatures(permissionsDict
                                , os.path.join(path,filename,'AndroidManifest.xml')
                                , os.path.join(path,filename,'apktool.yml'))
        # get method type
        methodTypeDictionary = methodType.getMethodType(methodsDictionary)
        features = []
        adj = []
        #handle dummy main row (all ones)
        firstRow = []
        for j in range(0,adjacencyIndex):
            firstRow.append(1)
            features.append([])
        adj.append(firstRow)
        #handle remained methods
        for i in range(1,adjacencyIndex):
            temp = []
            for j in range(0,adjacencyIndex):
                temp.append(0)
            adj.append(temp)
        for line in methodsArray:
            if(line.startswith('\t')):
                line2 = line[1:]
                adj[currentNode][methodsDictionary[line2]] += 1
            else:
                currentNode = methodsDictionary[line]
        # handle features matrix
        for method in methodsDictionary:
            currentI = methodsDictionary[method]
            for permission in permissionsDict[method]:
                features[currentI].append(permission)
            for hardwareFeature in hardwareDictionary[method]:
                features[currentI].append(hardwareFeature)
            features[currentI].append(methodTypeDictionary[method])
        featuresFile = open('features.txt','w')
        for line in features:
            featuresFile.write(str(line) + '\n')


def constructGraph(path, methodsDictionary, firstTime, methodsArray, permissionRef):
    global adjacencyIndex
    for filename in os.listdir(path):
        nextPath = os.path.join(path,filename)
        if os.path.isdir(nextPath):
            if(firstTime):
                if(not filename.startswith('smali')):
                    continue
            #it's a directory call constructGraph again (recursively)
            constructGraph(nextPath, methodsDictionary, False, methodsArray, permissionRef)
        else:
            #check extension
            if(filename.endswith('.smali')):
                constructGraphFromSmali(nextPath, methodsDictionary, methodsArray, permissionRef)

def constructGraphFromSmali(path, methodsDictionary, methodsArray, permissionRef):
    global adjacencyIndex
    currentClass = ''
    currentMethod = ''
    currentInvokeMethod = ''
    try:
        file = open(path, 'r', errors='ignore')
        for line in file:
            # check for current class
            if (line.startswith('.class')):
                for i in range(0, len(line)):
                    if line[i] == 'L':
                        currentClass = line[i:-1]
                        break
            # check for current method
            elif (line.startswith('.method')):
                currentMethod = line[line.rfind(' ') + 1:]
                formatedMethod = (currentClass + '->' + currentMethod)[:-1]
                methodsArray.append(formatedMethod)
                if (not (formatedMethod in methodsDictionary)):
                    methodsDictionary[formatedMethod] = adjacencyIndex
                    adjacencyIndex += 1
            # check for current invoke method
            elif (line.lstrip().startswith('invoke')):
                for j in range(0, len(line)):
                    if line[j] == 'L':
                        currentInvokeMethod = line[j:-1]
                        methodsArray.append(('\t'+currentInvokeMethod))
                        if(not (currentInvokeMethod in methodsDictionary)):
                            methodsDictionary[currentInvokeMethod] = adjacencyIndex
                            adjacencyIndex += 1
                        break

        file.close()
    except FileNotFoundError:
        return



#pass folder name to constructAllGraphs
adjacencyIndex = 1
# uniq is created using permissionsSmali.py
permissionRef = permissionsSmali.permissionsSmali()
t0 = time.time()
constructAllGraphs("c", permissionRef)
print(time.time() - t0)
print(adjacencyIndex)
