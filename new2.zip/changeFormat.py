def changeFormat(method):
    #method = method[:-1]
    className = ''
    returnType = ''
    methodName = ''
    i = 1
    currentClass = ''
    startMethodName = False
    startReturnType = False
    arrayFoundReturnType = False
    arrayFoundmethodName = False
    arrayFoundClassName = False
    methodStartParameters = method.rfind('(')
    returnTypeStartPoint = method.rfind(')')
    LFoundInMethod = False
    LFoundInReturnType = False
    while i < len(method):
        #check for [] (array)
        if(startMethodName and method[i] == ')'):
            if (arrayFoundmethodName):
                methodName += '[])'
                arrayFoundReturnType = False
                i += 1
                continue
        if (method[i] == '['):
            i += 1
            continue
        if(startReturnType and method[i] == 'L' and method[i-1] == '['):
            arrayFoundReturnType = True
            i += 1
            continue
        if(startMethodName and method[i] == 'L' and method[i - 1] == '['):
            arrayFoundmethodName = True
            i += 1
            continue
        if(method[i] == 'L' and (method[i-1] == ';' or method[i-1] == '(' or method[i-1] == ')'
             or (len(methodName) > 0 and methodName[len(methodName) - 1] == ','))): #chjeck for L
            i += 1
            continue
        if(method[i] == '/'): #check for /
            if (startReturnType):
                returnType += '.'
            elif (startMethodName):
                methodName += '.'
            else:
                className += '.'
            i += 1
            continue
        if(method[i] == ';'): #check for ;->
            if(i+1 < len(method) and method[i+1] == '-' and i+2 < len(method) and method[i+2] == '>'):
                currentClass = className[className.rfind('.')+1:]
                startMethodName = True
                i += 3
                continue
        if(method[i] == '<'):#check for <clinit> and <init>
            if(method.find('<init>',i) != -1): # check for <init>
                i += 6
                methodName += currentClass #replace it with class name
                continue
            elif(method.find('<clinit>',i) != -1):
                i += 8
                methodName += 'static' #replace it with static
                continue
        if(method[i] == ')'): #check for the start of return type
            startReturnType = True
            methodName += method[i]
            i += 1
            continue
        #check for prmitive types
            # V - void, B - byte, S - short, C - char, I - int
            # J - long (uses two registers), F - float, D - double
        if(method[i] == 'V'):
            if(startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'void'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'V'
                i += 1
                continue
        elif(method[i] == 'B'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'byte'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'B'
                i += 1
                continue
            elif(startMethodName and (i > methodStartParameters)):
                if(method[i-1] == '(' or method[i-1] == ';'):
                    methodName += 'byte'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters+1, i):
                        if(method[index] == 'L'):
                            LFoundInMethod = True
                        elif(method[index] == ';'):
                            LFoundInMethod = False
                    if(not LFoundInMethod):
                        methodName += 'byte'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'S'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'short'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'S'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'short'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'short'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'C'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'char'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'C'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'char'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'char'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'I'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'int'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'I'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'int'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'int'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'J'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'long'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'J'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'long'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'long'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'F'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'float'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'F'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'float'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'float'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'D'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'double'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'D'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'double'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'double'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        elif(method[i] == 'Z'):
            if (startReturnType):
                for index in range(returnTypeStartPoint + 1, i):
                    if (method[index] == 'L'):
                        LFoundInReturnType = True
                    elif (method[index] == ';'):
                        LFoundInReturnType = False
                if (not LFoundInReturnType):
                    returnType += 'boolean'
                    i += 1
                    continue
                LFoundInMethod = False
                returnType += 'Z'
                i += 1
                continue
            elif (startMethodName and (i > methodStartParameters)):
                if (method[i - 1] == '(' or method[i - 1] == ';'):
                    methodName += 'boolean'
                    if (i + 1 < len(method) and method[i + 1] != ')'):
                        methodName += ','
                    i += 1
                    continue
                else:
                    for index in range(methodStartParameters + 1, i):
                        if (method[index] == 'L'):
                            LFoundInMethod = True
                        elif (method[index] == ';'):
                            LFoundInMethod = False
                    if (not LFoundInMethod):
                        methodName += 'boolean'
                        if (i + 1 < len(method) and method[i + 1] != ')'):
                            methodName += ','
                        i += 1
                        continue
                    LFoundInMethod = False
        #check for ;
        if(method[i] == ';'):
            if (startMethodName and i+1 < len(method) and method[i+1] != ')'):
                if (arrayFoundReturnType):
                    returnType += '[],'
                    arrayFoundReturnType = False
                    i += 1
                    continue
                elif (arrayFoundmethodName):
                    methodName += '[],'
                    arrayFoundmethodName = False
                    i += 1
                    continue
                methodName += ','
            i += 1
            continue
        if(startReturnType):
            returnType += method[i]
        elif(startMethodName):
            methodName += method[i]
        else:
            className += method[i]
        i += 1
    if (arrayFoundReturnType):
        returnType += '[]'
        arrayFoundReturnType = False
        i += 1
    return '<' + className + ': '+ returnType + ' '+ methodName + '>'
