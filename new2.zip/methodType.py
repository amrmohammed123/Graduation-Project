# -*- coding: utf-8 -*-
"""
Created on Sun Mar  3 14:37:00 2019

@author: Bassant
"""

'''
methodsFile="G:\\Dataset\\app11\\app114.txt"
feat =open("G:\\Extract_Features\\types.txt",'w')
'''

"""
metheod is classified as System API if it starts with:
    android.xxxxx
    java.xxxxxxx
    com.android.xxxxx
    com.java.xxxxx

method is classified as third-party API if it starts with:
    com.google.xxxxxx
    come.facebook.xxxxx
    com.yahooapis.xxxxxx

method is classified as component API if it starts with:
    android.provider.xxxx
    or contains provider anywhere
    
method is classified as other otherwise
"""
    
def getMethodType(methodsDictionary):
    methodTypeDictionary = {key: '' for key in methodsDictionary.keys()}
    for m in methodTypeDictionary:
        if(m == 'dummyMain'):
            continue
        mSplit=m.split('/')
        if (len(mSplit) < 2):
            methodTypeDictionary[m] = "Others"
        if (mSplit[1]=="provider") | ("providers" in mSplit) | (mSplit[1]=="activity") | ("activities" in mSplit) | (mSplit[1]=="service") | ("services" in mSplit) | (mSplit[1]=="reciver") | ("recievers" in mSplit):
            methodTypeDictionary[m] = "Component API"
        elif (mSplit[0]=="Landroid") | (mSplit[1]=="android") | (mSplit[0]=="Ljava") | (mSplit[1]=="java"):
            methodTypeDictionary[m] = "System API"
        elif (mSplit[1]=="google") | (mSplit[1]=="facebook") | (mSplit[1]=="yahooapis"):
            methodTypeDictionary[m] = "Third-Party API"
        else:
            methodTypeDictionary[m] = "Others"
    return methodTypeDictionary