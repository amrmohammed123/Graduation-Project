# -*- coding: utf-8 -*-
"""
Created on Fri Mar  8 16:51:22 2019

@author: Bassant
"""

import permissionsSmali
import timeit

def extractPermissions(methodsDictionary, androidManifestPath, permissionRef):
    permissionDictionary = {key:set() for key in methodsDictionary.keys()}
    componentPermissions = []
    #extract requested permissions from uses-permission tag
    androidManifest = open(androidManifestPath, 'r')

    for line in androidManifest:
        line = line.lstrip()
        if(line.startswith('<uses-permission')):
            quoteFound = False
            permission = ''
            start = line.find('android:name')
            if(start != -1):
                for i in range(start+12,len(line)):
                    if(line[i] == '"'):
                        if(quoteFound):
                            # add the permission to dummyMain
                            permissionDictionary['dummyMain'].add(permission.strip())
                            break
                        else:
                            quoteFound = True
                            continue
                    if(quoteFound):
                        permission += line[i]
        #find component permissions
        #find component class name
        if(line.startswith('<activity') or line.startswith('<receiver')
            or line.startswith('<application')):
            quoteFound = False
            componentName = ''
            start = line.find('android:name')
            if(start != -1):
                for i in range(start+12,len(line)):
                    if(line[i] == '"'):
                        if(quoteFound):
                            break
                        else:
                            quoteFound = True
                            continue
                    if(quoteFound):
                        componentName += line[i]
            componentPermission = ''
            quoteFound = False
            #find component permission
            start = line.find('android:permission')
            if(start != -1):
                for i in range(start+18,len(line)):
                    if(line[i] == '"'):
                        if(quoteFound):
                            break
                        else:
                            quoteFound = True
                            continue
                    if(quoteFound):
                        componentPermission += line[i]
            if(componentPermission != '' and componentName != ''):
                componentPermissions.append((componentName,componentPermission))
    androidManifest.close()
    #map permissions to methods
    for currentPermission in permissionDictionary['dummyMain']:
        if(currentPermission in permissionRef):
            for currentMethod in permissionRef[currentPermission]:
                if(currentMethod in methodsDictionary):
                    permissionDictionary[currentMethod].add(currentPermission)
    #add components permissions
    for currentMethod in methodsDictionary:
        for component in componentPermissions:
            if(currentMethod.startswith(component[0])):
                permissionDictionary[currentMethod].add(component[1])
    '''
    f = open('checkPermissions.txt','w')
    for key in permissionDictionary:
        value = str(permissionDictionary[key])
        if(value == 'set()'):
            f.write(key + '\n')
        else:
            f.write(key + ' : ' + value + '\n')
    '''
    return permissionDictionary
