# -*- coding: utf-8 -*-
"""
Created on Sun Mar  3 14:37:00 2019

@author: Bassant
"""


methodsFile="G:\\Dataset\\app11\\app114.txt"
feat =open("G:\\Extract_Features\\types.txt",'w')

"""
metheod is classified as System API if it starts with:
    android.xxxxx
    java.xxxxxxx
    com.android.xxxxx
    com.java.xxxxx

method is classified as third-party API if it starts with:
    com.google.xxxxxx
    come.facebook.xxxxx
    com.yahooapis.xxxxxx

method is classified as component API if it starts with:
    android.provider.xxxx
    or contains provider anywahere
    
method is classified as other otherwise
"""
    
with open(methodsFile) as mthds:
    methods=mthds.read().splitlines()
    for m in methods:
        feat.write(m+':'+'\n')
        if m=='dummyMain:0':
            None
        else:
            mSplit=m.split('/')
            if (mSplit[1]=="provider") | ("providers" in mSplit) | (mSplit[1]=="activity") | ("activities" in mSplit) | (mSplit[1]=="service") | ("services" in mSplit) | (mSplit[1]=="reciver") | ("recievers" in mSplit):
                feat.write("Type: Component API")
            elif (mSplit[0]=="Landroid") | (mSplit[1]=="android") | (mSplit[0]=="Ljava") | (mSplit[1]=="java"):
                feat.write("Type: System API")
            elif (mSplit[1]=="google") | (mSplit[1]=="facebook") | (mSplit[1]=="yahooapis"):
                feat.write("Type: Third-Party API")
            else:
                feat.write("Type: Others")
            feat.write("\n")
mthds.close()
feat.close()