"""

execHttpRequest()  "permission ?"
SendBroadcast() "intent filter? "

"""

from collections import defaultdict
import pprint

Suspicious_APIs =  ['Landroid/telephony/TelephonyManager;->getDeviceId()',
                    'Landroid/telephony/TelephonyManager;->getImei()',
                    'Landroid/telephony/TelephonyManager;->getSubscriberId()',
                    'Landroid/telephony/TelephonyManager;->getSimSerialNumber()',
                    'Landroid/net/wifi/WifiManager;->setWifiEnabled()',
                    'Landroid/telephony/SmsManager;->sendTextMessage()',
                    'Landroid/telephony/SmsManager;->sendDataMessage',
                    'Landroid/location/Location;->getLatitude()',
                    'Landroid/location/Location;->getLongitude()',
                    'Landroid/location/LocationManager;->getLastKnownLocation',
                    'Landroid/location/LocationManager;->requestLocationUpdates()',
                    'Ljava/lang/Runtime;->exec()',
                    'Ldalvik.system.DexClassLoader;->Loadclass()',
                    'Ljavax/crypto/CipherCipher;->getInstance()',
                   ]

methodsFile = "C:\\Users\\user\\Documents\\enas\\GP\\6eb51ab4443b237ffdfee833801b39a41e5b6f67d70e38193d96bb61472a4c14_dictionary-3.txt"
feat = open("C:\\Users\\user\\Documents\\enas\\GP\\SuspAPI.txt", 'w+')
suspicious_Dict = open("C:\\Users\\user\\Documents\\enas\\GP\\SuspDic.txt", 'w+')


with open(methodsFile, 'rt') as inp_file:
    my_dict = defaultdict(list)
    for line in inp_file:
                 for API in Suspicious_APIs:
                    if API in line:
                        my_dict[line] = 'true'
                        feat.write(line)
                        feat.write(API + '\n' + '\n')
                        break
                    else:
                        my_dict[line] = 'false'
    pprint.pprint(my_dict,suspicious_Dict)
    feat.close()
    suspicious_Dict.close()